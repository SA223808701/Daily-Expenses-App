import React, { Component } from 'react';
import { View, Text, StyleSheet } from 'react-native';