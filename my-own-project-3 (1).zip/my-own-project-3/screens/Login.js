import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Platform,
  StatusBar,
  ImageBackground,
  Image
} from 'react-native';

import {TouchableOpacity} from "react-native-gesture-handler";
import { RFValue } from "react-native-responsive-fontsize";

export default class LoginScreen extends Component {
    //constructor(props) {
     // super(props);
        //this.state = {};
   
   // ComponentDidMount(){

    //};



render() {
        return (
            <View style={styles.container}>
                <SafeAreaView style={styles.droidSafeArea} />
                <ImageBackground
                style={styles.container}
                source={require('../assets/bg1.png')}>

       <View style={styles.appTitle}>
              <Image
              style={styles.appIcon}
                source={require("../assets/AppLogo.png")}>
            </Image>
              <Text style = {styles.appTitleText}>{'Daily Expenses'}</Text>
                    </View>
                    <View style={styles.buttonContainer}>
                    <TouchableOpacity
                    style={styles.button}
                    >
                    <Text style={styles.googleText}> Sign in with google</Text>
                    </TouchableOpacity>
                    </View>
                    </ImageBackground>
                    </View>
                    
        )                    
                    }
                     }


const styles = StyleSheet.create({
    container: {
        flex: 1,
       // backgroundColor: "pink",
       height: 580,
       width: 350,
       justifyContent:'space-evenly',
       alignItems:'center',
       resizeMode: 'cover',
    },

    appTitleText: {
        flex: 0.4,
        justifyContent: 'space-evenly',
        textAlign:'center',
        alignItems: "center",
        fontFamily: 'Didot',
        fontWeight: 'bold',
        fontSize:RFValue(28),
        color: 'darkblue'
       
    },

    appIcon:{
      width:RFValue( 135),
      height:RFValue( 100),
     justifyContent: 'center',
       alignItems: "center",
       resizeMode:"contain"
      
    },
button: {
  width: 145,
  height: 50,
  justifyContent:'space-evenly',
  alignItems:'center',
  backgroundColor:'pink',
  borderRadius:30,
}
    
});